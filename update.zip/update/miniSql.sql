USE PHDTracking;

INSERT INTO UserRoleMember VALUES('super');
INSERT INTO [User] VALUES ('5','1002','Mosh','Mosh','Mosh','9777644355456','mosh@gmail.com');

