1.connect to your azure server 

2.Run the miniSql.sql file to update the database
     ->run INSERT INTO UserRoleMember VALUES('super');
     ... CHECK THE RoleID that correspond with the super column
     --> INSERT INTO [User] VALUES ('5','**RoleID***','Mosh','Mosh','Mosh','9777644355456','mosh@gmail.com');

3. UPDATE THE frontEnd folder with frontEnd2 files **(COPY ALL THE FILES IN frontEnd2 to frontEnd folder);

4.go to router.js file then add this code
       -->
        Router.get('/super',(req,res)=>{
          res.sendFile(path.join(__dirname,`${Paths}/superUser/index.html`));
          })

5..Everything should work fine at this point...

6. USE   email = mosh@gmail.com 
          password = Mosh

    To login as superUser      